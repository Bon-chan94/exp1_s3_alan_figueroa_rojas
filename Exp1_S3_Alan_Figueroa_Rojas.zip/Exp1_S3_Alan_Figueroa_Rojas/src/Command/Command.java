// command/Command.java
package Command;

public interface Command {
    void ejecutar();
}
