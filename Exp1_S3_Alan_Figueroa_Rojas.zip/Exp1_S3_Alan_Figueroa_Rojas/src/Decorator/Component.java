// decorator/Component.java
package Decorator;

public interface Component {
    double getPrecio();
}
